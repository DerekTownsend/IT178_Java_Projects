/* The IllegalEmailException class
    Anderson, Franceschi
*/

public class IllegalEmailException extends IllegalArgumentException
{
  public IllegalEmailException( String message )
  {
    super( message );
  }
}