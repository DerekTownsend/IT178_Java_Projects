// First program in Java
// your name here

public class FirstProgram
{
  public static void main( String [] args )
  {
 	  System.out.println( "Programming is not a spectator sport!" );

	  System.exit( 0 );
  }
}