/*  A demonstration of the Math round method
    Anderson, Franceschi
*/

public class MathRounding
{
  public static void main( String [] args )
  {
    System.out.println( "23.4 rounded is " + Math.round( 23.4 ) );
    System.out.println( "23.49 rounded is " + Math.round( 23.49 ) );
    System.out.println( "23.5 rounded is " + Math.round( 23.5 ) );
    System.out.println( "23.51 rounded is " + Math.round( 23.51 ) );
    System.out.println( "23.6 rounded is " + Math.round( 23.6 ) );
  }
}