/*  A demonstration of trying to use a null object reference
    Anderson, Franceschi
*/

public class NullReference
{
  public static void main( String [] args )
  {
     SimpleDate aDate;
     aDate.setMonth( 5 );
  }
}
