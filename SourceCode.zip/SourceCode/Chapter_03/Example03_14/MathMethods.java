/*  A demonstration of some Math class methods
    Anderson, Franceschi
*/

public class MathMethods
{
  public static void main( String [] args )
  {
    double d2 = Math.log( 5 );
    System.out.println( "\nThe log of 5 is " + d2 );

    double d4 = Math.sqrt( 9 );
    System.out.println( "\nThe square root of 9 is " + d4 );

    double fourCubed = Math.pow( 4, 3 );
    System.out.println( "\n4 to the power 3 is " + fourCubed );

    double bigNumber = Math.pow( 43.5, 3.4 );
    System.out.println( "\n43.5 to the power 3.4 is " + bigNumber );
  }
}



