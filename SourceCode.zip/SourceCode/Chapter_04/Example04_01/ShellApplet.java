/* An applet shell
   Anderson, Franceschi
*/

import javax.swing.JApplet;
import java.awt.Graphics;

public class ShellApplet extends JApplet
{
  public void paint( Graphics g )
  {
    super.paint( g );
    // include graphics code here
  }
}