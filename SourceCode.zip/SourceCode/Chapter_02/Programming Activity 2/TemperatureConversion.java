/* Temperature Conversion
   Anderson, Franceschi
*/

public class TemperatureConversion
{
   public static void main( String [] args )
   {
      //***** 1. declare any constants here
	
			
      //***** 2.  declare temperature in Fahrenheit as an int 
	  
	  		
      //***** 3. calculate equivalent Celsius temperature	
	  
	  		
      //***** 4. output the temperature in Celsius
	   
												  
      //***** 5. convert Celsius temperature back to Fahrenheit
		
				
      //***** 6. output Fahrenheit temperature to check correctness 
		
				
   }
} 