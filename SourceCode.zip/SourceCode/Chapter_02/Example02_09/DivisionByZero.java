/* DivisionByZero Class
   Anderson, Franceschi
*/

public class DivisionByZero
{
  public static void main( String [] args )
  {
    double result1 = 4.3 / 0.0;
    System.out.println( "The value of result1 is " + result1 );

    double result2 = 0.0 / 0.0;
    System.out.println( "The value of result2 is " + result2 );

    int result3 = 4 / 0;
    System.out.println( "The value of result3 is " + result3 );
  }
}


