/* An Application Shell
   Anderson, Franceschi
*/
public class ShellApplication
{
  public static void main( String [] args ) // required
  {
      // write your code here
  }
}