/* ShortcutOperators Class
   Anderson, Franceschi
*/

public class ShortcutOperators
{
  public static void main( String [] args )
  {
    int a = 6;
    int b = 2;

    System.out.println( "At the beginning, a is " + a );
    System.out.println( "Increment a with prefix notation: " + ++a );
    System.out.println( "In the end, a is " + a );

    System.out.println( "\nAt the beginning, b is " + b );
    System.out.println( "Increment b with postfix notation: " + b++ );
    System.out.println( "In the end, b is " + b );
  }
}



