/*  Literals Class
    Anderson, Franceschi
*/

public class Literals
{
  public static void main( String [] args )
  {
    System.out.println( "One potato\nTwo potatoes\n");
    System.out.println( "\tTabs can make the output easier to read" );
    System.out.println( "She said, \"Java is fun\"" );
  }
}



