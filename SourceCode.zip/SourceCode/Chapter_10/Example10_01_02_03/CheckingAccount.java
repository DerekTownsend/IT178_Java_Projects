/* CheckingAccount class, version 1
   Anderson, Franceschi
*/
public class CheckingAccount extends BankAccount
{ }
