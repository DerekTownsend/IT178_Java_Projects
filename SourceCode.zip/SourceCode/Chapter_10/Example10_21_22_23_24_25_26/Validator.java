/** Validator interface
*   Anderson, Franceschi
*/
public interface Validator
{
  public boolean isValid( );
}